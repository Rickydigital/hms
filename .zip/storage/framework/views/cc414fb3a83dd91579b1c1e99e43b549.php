
<?php
    $user = auth()->user();
?>

<!-- Mobile Bottom Navigation -->
<div class="mobile-bottom-nav d-lg-none">
    <div class="nav-items-wrapper">
        <div class="nav-items">

            <a href="<?php echo e(route('dashboard')); ?>" class="nav-item <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                <i class="bi bi-speedometer2"></i>
                <span>Dashboard</span>
            </a>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view patients')): ?>
            <a href="<?php echo e(route('patients.index')); ?>" class="nav-item <?php echo e(request()->is('patients*') ? 'active' : ''); ?>">
                <i class="bi bi-person-heart"></i>
                <span>Patients</span>
            </a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view visits', 'create visit'])): ?>
            <a href="<?php echo e(route('doctor.opd')); ?>" class="nav-item <?php echo e(request()->is('doctor/opd*') || request()->is('visits*') ? 'active' : ''); ?>">
                <i class="bi bi-calendar-check"></i>
                <span>Today OPD</span>
            </a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access billing')): ?>
            <a href="<?php echo e(route('billing.index')); ?>" class="nav-item <?php echo e(request()->is('billing*') ? 'active' : ''); ?>">
                <i class="bi bi-credit-card-2-front-fill text-danger"></i>
                <span>Payment</span>
            </a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('issue medicine')): ?>
            <a href="<?php echo e(route('pharmacy.index')); ?>" class="nav-item <?php echo e(request()->is('pharmacy*') ? 'active' : ''); ?>">
                <i class="bi bi-capsule"></i>
                <span>Pharmacy</span>
            </a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enter lab results')): ?>
            <a href="<?php echo e(route('lab.index')); ?>" class="nav-item <?php echo e(request()->is('lab*') ? 'active' : ''); ?>">
                <i class="bi bi-vial"></i>
                <span>Lab</span>
            </a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('issue store items')): ?>
            <a href="<?php echo e(route('store.purchase.index')); ?>" class="nav-item <?php echo e(request()->is('store*') ? 'active' : ''); ?>">
                <i class="bi bi-box-seam"></i>
                <span>Store</span>
            </a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage users')): ?>
            <a href="<?php echo e(route('users.index')); ?>" class="nav-item <?php echo e(request()->is('users*') ? 'active' : ''); ?>">
                <i class="bi bi-person-gear"></i>
                <span>Users</span>
            </a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage settings')): ?>
            <a href="<?php echo e(route('admin.settings')); ?>" class="nav-item <?php echo e(request()->is('admin/settings*') ? 'active' : ''); ?>">
                <i class="bi bi-gear-fill"></i>
                <span>Settings</span>
            </a>
            <?php endif; ?>

        </div>
    </div>
</div>

<!-- Desktop Sidebar -->
<div class="left-side-menu d-none d-lg-block">
    <div class="slimscroll-menu">
        <div id="sidebar-menu">
            <ul class="metismenu" id="side-menu">

                <li class="menu-title text-muted small text-uppercase">Main Menu</li>

                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                        <i class="bi bi-speedometer2 text-primary"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view patients')): ?>
                <li>
                    <a href="<?php echo e(route('patients.index')); ?>" class="waves-effect <?php echo e(request()->is('patients*') ? 'active' : ''); ?>">
                        <i class="bi bi-person-heart text-success"></i>
                        <span>Patients</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view visits', 'create visit'])): ?>
                <li>
                    <a href="<?php echo e(route('doctor.opd')); ?>" class="waves-effect <?php echo e(request()->is('doctor/opd*') || request()->is('visits*') ? 'active' : ''); ?>">
                        <i class="bi bi-calendar-check text-info"></i>
                        <span>Today OPD</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access billing')): ?>
                <li>
                    <a href="<?php echo e(route('billing.index')); ?>" class="waves-effect <?php echo e(request()->is('billing*') ? 'active' : ''); ?>">
                        <i class="bi bi-credit-card-2-front-fill text-danger fs-5"></i>
                        <span class="fw-bold">Payment & Billing</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('issue medicine')): ?>
                <li>
                    <a href="<?php echo e(route('pharmacy.index')); ?>" class="waves-effect <?php echo e(request()->is('pharmacy*') ? 'active' : ''); ?>">
                        <i class="bi bi-capsule text-warning"></i>
                        <span>Pharmacy</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enter lab results')): ?>
                <li>
                    <a href="<?php echo e(route('lab.index')); ?>" class="waves-effect <?php echo e(request()->is('lab*') ? 'active' : ''); ?>">
                        <i class="bi bi-vial text-purple"></i>
                        <span>Laboratory</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('issue store items')): ?>
                <li>
                    <a href="<?php echo e(route('store.purchase.index')); ?>" class="waves-effect <?php echo e(request()->is('store*') ? 'active' : ''); ?>">
                        <i class="bi bi-box-seam text-secondary"></i>
                        <span>Store & Purchase</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage users', 'manage settings'])): ?>
                <li class="menu-title text-muted small mt-3">Administration</li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage users')): ?>
                <li>
                    <a href="<?php echo e(route('users.index')); ?>" class="waves-effect <?php echo e(request()->is('users*') ? 'active' : ''); ?>">
                        <i class="bi bi-person-gear text-warning"></i>
                        <span>Manage Users</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage settings')): ?>
                <li>
                    <a href="<?php echo e(route('admin.settings')); ?>" class="waves-effect <?php echo e(request()->is('admin/settings*') ? 'active' : ''); ?>">
                        <i class="bi bi-gear-fill text-secondary"></i>
                        <span>Hospital Settings</span>
                    </a>
                </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</div><?php /**PATH C:\Users\Ricky\Desktop\hms\resources\views/components/side-bar.blade.php ENDPATH**/ ?>