

<?php $__env->startSection('title', 'Admin Dashboard • CareWell HMS'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 text-gray-800 fw-bold">CareWell HMS • Admin Dashboard</h1>
        <div class="text-muted">Welcome back, <?php echo e(auth()->user()->name); ?></div>
    </div>

    <!-- STATS CARDS -->
    <div class="row">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Patients</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(number_format($total_patients)); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Today's OPD</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($today_opd); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar-check fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Stock Value</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">Tsh<?php echo e(number_format($total_stock_value, 0)); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-boxes fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Today's Revenue</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">Tsh<?php echo e(number_format($today_revenue, 0)); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-money-bill-wave fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- QUICK ADMIN ACTIONS -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-primary text-white">
            <h6 class="m-0 font-weight-bold">Quick Admin Actions</h6>
        </div>
        <div class="card-body">
            <div class="row g-3">

                <div class="col-md-3 col-6">
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-outline-primary w-100 py-3 shadow-sm">
                        <i class="bi bi-person-plus-fill fs-4"></i><br>
                        <span class="small fw-bold">Add New User</span>
                    </a>
                </div>

                <div class="col-md-3 col-6">
                    <a href="<?php echo e(route('admin.roles')); ?>" class="btn btn-outline-info w-100 py-3 shadow-sm">
                        <i class="bi bi-shield-check fs-4"></i><br>
                        <span class="small fw-bold">Manage Roles</span>
                    </a>
                </div>

                <div class="col-md-3 col-6">
                    <a href="<?php echo e(route('lab-tests.index')); ?>" class="btn btn-outline-success w-100 py-3 shadow-sm">
                        <i class="bi bi-vial fs-4"></i><br>
                        <span class="small fw-bold">Add Lab Test</span>
                    </a>
                </div>

                <div class="col-md-3 col-6">
                    <a href="<?php echo e(route('medicines.index')); ?>" class="btn btn-outline-warning w-100 py-3 shadow-sm">
                        <i class="bi bi-capsule-pill fs-4"></i><br>
                        <span class="small fw-bold">Add Medicine</span>
                    </a>
                </div>

                <div class="col-md-3 col-6">
                    <a href="<?php echo e(route('store-items.index')); ?>" class="btn btn-outline-secondary w-100 py-3 shadow-sm">
                        <i class="bi bi-box-seam fs-4"></i><br>
                        <span class="small fw-bold">Add Store Item</span>
                    </a>
                </div>

                <div class="col-md-3 col-6">
                    <a href="<?php echo e(route('wards.index')); ?>" class="btn btn-outline-danger w-100 py-3 shadow-sm">
                        <i class="bi bi-building fs-4"></i><br>
                        <span class="small fw-bold">Add Ward / Bed</span>
                    </a>
                </div>

                <div class="col-md-3 col-6">
                    <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-outline-dark w-100 py-3 shadow-sm">
                        <i class="bi bi-truck fs-4"></i><br>
                        <span class="small fw-bold">Add Supplier</span>
                    </a>
                </div>

                <div class="col-md-3 col-6">
                    <a href="<?php echo e(route('admin.medicine.logs')); ?>" class="btn btn-outline-purple w-100 py-3 shadow-sm">
                        <i class="bi bi-journal-medical fs-4"></i><br>
                        <span class="small fw-bold">Medicine Logs</span>
                    </a>
                </div>

            </div>
        </div>
    </div>

    <!-- CHARTS -->
    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Revenue Trend (Last 7 Days)</h6>
                </div>
                <div class="card-body">
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>
        </div>

        <div class="col-lg-6 mb-4">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-success">OPD Patients Trend</h6>
                </div>
                <div class="card-body">
                    <canvas id="opdChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- TOP SELLING MEDICINES -->
    <div class="card shadow">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Top Selling Medicines (This Month)</h6>
            <a href="<?php echo e(route('medicines.index')); ?>" class="btn btn-sm btn-outline-primary">
                View All Medicines
            </a>
        </div>
        <div class="card-body">
            <?php if($top_medicines->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Medicine Name</th>
                            <th>Category</th>
                            <th>Qty Sold</th>
                            <th>Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $top_medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><strong><?php echo e($item->medicine->medicine_name); ?></strong></td>
                            <td><?php echo e($item->medicine->category ?? 'General'); ?></td>
                            <td><span class="badge bg-success fs-6"><?php echo e($item->total); ?></span></td>
                            <td>Tsh<?php echo e(number_format($item->total * ($item->medicine->selling_price ?? 0), 0)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-muted text-center py-4">No sales recorded this month yet.</p>
            <?php endif; ?>
        </div>
    </div>

</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx1 = document.getElementById('revenueChart').getContext('2d');
    new Chart(ctx1, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($revenue_chart['labels'], 15, 512) ?>,
            datasets: [{
                label: 'Daily Revenue (Tsh)',
                data: <?php echo json_encode($revenue_chart['data'], 15, 512) ?>,
                borderColor: '#4e73df',
                backgroundColor: 'rgba(78, 115, 223, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: { plugins: { legend: { display: false } } }
    });

    const ctx2 = document.getElementById('opdChart').getContext('2d');
    new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($opd_chart['labels'], 15, 512) ?>,
            datasets: [{
                label: 'OPD Patients',
                data: <?php echo json_encode($opd_chart['data'], 15, 512) ?>,
                backgroundColor: '#1cc88a'
            }]
        },
        options: { plugins: { legend: { display: false } } }
    });
</script>

<style>
.btn-outline-purple {
    border-color: #6f42c1;
    color: #6f42c1;
}
.btn-outline-purple:hover {
    background-color: #6f42c1;
    color: white;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ricky\Desktop\hms\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>