
<?php $__env->startSection('title', 'Lab • CareWell HMS'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-light">
    <!-- TOP HEADER -->
    <div class="bg-primary text-white py-5 shadow-sm">
        <div class="container">
            <div class="row align-items-center">
                <div class="col">
                    <h1 class="display-5 fw-bold mb-1">Laboratory Module</h1>
                    <p class="lead mb-0 opacity-90">Welcome back, <?php echo e(Auth::user()->name); ?></p>
                </div>
                <div class="col-auto">
                    <div class="text-end">
                        <h5 class="mb-0"><?php echo e(now()->format('d M Y')); ?></h5>
                        <small><?php echo e(now()->format('l')); ?></small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid py-4">
        <div class="row g-4">

            <!-- LEFT: SEARCH HISTORY + TODAY'S COMPLETED -->
            <div class="col-lg-5">
                <div class="sticky-top" style="top: 20px;">

                    <!-- SEARCH PATIENT LAB HISTORY -->
                    <div class="card border-0 shadow-lg rounded-4 mb-4">
                        <div class="card-header bg-white border-bottom-0 py-4">
                            <h5 class="mb-0 text-primary fw-bold">
                                Search Patient Lab History
                            </h5>
                        </div>
                        <div class="card-body p-4">
                            <form action="<?php echo e(route('lab.index')); ?>" method="GET">
                                <div class="input-group input-group-lg shadow-sm">
                                    <span class="input-group-text bg-white border-end-0">
                                        Search
                                    </span>
                                    <input type="text" name="search" class="form-control border-start-0 ps-0" 
                                           placeholder="Patient ID • Name • Phone" 
                                           value="<?php echo e(request('search')); ?>" autofocus>
                                    <button class="btn btn-primary">Go</button>
                                </div>
                            </form>

                            <?php if(request('search')): ?>
                                <?php if($history->count()): ?>
                                    <div class="mt-4" style="max-height: 60vh; overflow-y: auto;">
                                        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="border rounded-3 p-3 mb-3 bg-white shadow-sm">
                                                <div class="d-flex justify-content-between align-items-start mb-2">
                                                    <div>
                                                        <h6 class="mb-0 text-success fw-bold"><?php echo e($item['patient']->name); ?></h6>
                                                        <small class="text-muted"><?php echo e($item['patient']->patient_id); ?> • <?php echo e($item['patient']->phone); ?></small>
                                                    </div>
                                                </div>
                                                <div class="small">
                                                    <?php $__currentLoopData = $item['orders']->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="d-flex justify-content-between py-1 border-bottom border-light">
                                                            <span class="text-dark">
                                                                <strong><?php echo e($order->test->test_name); ?></strong>
                                                                <br><small class="text-muted"><?php echo e($order->visit->created_at->format('d M Y')); ?></small>
                                                            </span>
                                                            <span>
                                                                <?php if($order->is_completed): ?>
                                                                    <span class="badge rounded-pill bg-<?php echo e($order->result?->is_abnormal ? 'danger' : 'success'); ?>">
                                                                        <?php echo e($order->result?->is_abnormal ? 'Abnormal' : 'Normal'); ?>

                                                                    </span>
                                                                <?php else: ?>
                                                                    <span class="badge bg-warning text-dark">Pending</span>
                                                                <?php endif; ?>
                                                            </span>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item['orders']->count() > 5): ?>
                                                        <small class="text-muted">+<?php echo e($item['orders']->count() - 5); ?> more...</small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <div class="text-center py-5 text-muted">
                                        <i class="bi bi-inbox fs-1"></i>
                                        <p class="mt-3">No lab history found</p>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- TODAY'S COMPLETED -->
                    <div class="card border-0 shadow-lg rounded-4">
                        <div class="card-header bg-success text-white py-4 rounded-top-4">
                            <h5 class="mb-0">Today's Completed (<?php echo e($completedToday->count()); ?>)</h5>
                        </div>
                        <div class="card-body p-0" style="max-height: 50vh; overflow-y: auto;">
                            <?php $__empty_1 = true; $__currentLoopData = $completedToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="px-4 py-3 border-bottom hover-bg-light">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="flex-grow-1">
                                            <strong class="text-success"><?php echo e($order->test->test_name); ?></strong><br>
                                            <small class="text-muted">
                                                <?php echo e($order->visit->patient->name); ?> • <?php echo e($order->completed_at->format('h:i A')); ?>

                                            </small>
                                        </div>
                                        <div>
                                            <?php if($order->result?->is_abnormal): ?>
                                                <span class="badge bg-danger fs-6">Abnormal</span>
                                            <?php else: ?>
                                                <span class="badge bg-success fs-6">Normal</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center py-5 text-muted">
                                    No tests completed today
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RIGHT: PENDING TESTS (MAIN WORK AREA) -->
            <div class="col-lg-7">
                <div class="card border-0 shadow-lg rounded-4 h-100">
                    <div class="card-header bg-primary text-white py-4 rounded-top-4 d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Pending Tests • <?php echo e($pending->count()); ?></h4>
                        <span class="badge bg-white text-primary fs-5"><?php echo e($pending->count()); ?> Active</span>
                    </div>
                    <div class="card-body p-4" style="max-height: 85vh; overflow-y: auto;">
                        <?php $__empty_1 = true; $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card mb-4 border-0 shadow-sm hover-lift rounded-4 border-start border-primary border-5">
                                <div class="card-body p-4">
                                    <div class="row g-4">
                                        <div class="col-md-8">
                                            <h5 class="text-primary mb-2"><?php echo e($order->test->test_name); ?></h5>
                                            <div class="mb-3">
                                                <strong>Patient:</strong> <?php echo e($order->visit->patient->name); ?>

                                                <span class="text-muted">• <?php echo e($order->visit->patient->patient_id); ?></span>
                                            </div>
                                            <div class="small text-muted">
                                                Ordered: <?php echo e($order->visit->created_at->format('d M Y • h:i A')); ?>

                                                <?php if($order->extra_instruction): ?>
                                                    <br><span class="text-info fw-bold">Note: <?php echo e($order->extra_instruction); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4 text-md-end">
                                            <a href="<?php echo e(route('lab.order.show', $order)); ?>" 
                                               class="btn btn-success btn-lg rounded-pill px-5 shadow">
                                                Enter Result
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center py-5">
                                <div class="mb-4">
                                    <i class="bi bi-check-circle-fill text-success" style="font-size: 4rem;"></i>
                                </div>
                                <h3 class="text-success fw-bold">All Clear!</h3>
                                <p class="text-muted">No pending tests. Excellent work!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.hover-lift {
    transition: all 0.3s ease;
}
.hover-lift:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.12) !important;
}
.hover-bg-light:hover {
    background-color: #f8f9fa !important;
}
.rounded-4 {
    border-radius: 1rem !important;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ricky\Desktop\hms\resources\views/lab/index.blade.php ENDPATH**/ ?>