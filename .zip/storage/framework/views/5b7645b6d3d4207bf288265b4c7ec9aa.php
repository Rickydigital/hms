

<?php $__env->startSection('title', 'Medicine Stock Logs • CareWell HMS'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 text-gray-800">
            <i class="fas fa-prescription-bottle-alt"></i> Medicine Stock Movement Logs
        </h1>
        <span class="badge bg-primary fs-5 px-4 py-2"><?php echo e($logs->total()); ?> Total Records</span>
    </div>

    <!-- FILTER CARD -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-primary text-white">
            <h6 class="m-0 font-weight-bold">Filter Logs</h6>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.medicine.logs.filter')); ?>" method="GET">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Medicine</label>
                        <select name="medicine_id" class="form-select select2">
                            <option value="">All Medicines</option>
                            <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($m->id); ?>" <?php echo e(request('medicine_id') == $m->id ? 'selected' : ''); ?>>
                                    <?php echo e($m->medicine_name); ?> <?php if($m->generic_name): ?> • <?php echo e($m->generic_name); ?> <?php endif; ?>
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-bold">Type</label>
                        <select name="type" class="form-select">
                            <option value="">All Types</option>
                            <option value="purchase" <?php echo e(request('type') == 'purchase' ? 'selected' : ''); ?>>Purchase (IN)</option>
                            <option value="sale" <?php echo e(request('type') == 'sale' ? 'selected' : ''); ?>>Sale (OUT)</option>
                            <option value="return" <?php echo e(request('type') == 'return' ? 'selected' : ''); ?>>Return</option>
                            <option value="damage" <?php echo e(request('type') == 'damage' ? 'selected' : ''); ?>>Damage</option>
                            <option value="expiry" <?php echo e(request('type') == 'expiry' ? 'selected' : ''); ?>>Expiry</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-bold">From Date</label>
                        <input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-bold">To Date</label>
                        <input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>">
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-success me-2">
                            <i class="fas fa-filter"></i> Apply Filter
                        </button>
                        <a href="<?php echo e(route('admin.medicine.logs')); ?>" class="btn btn-secondary">
                            <i class="fas fa-sync"></i> Clear
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- LOGS TABLE -->
    <div class="card shadow">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="bg-gradient-primary text-green">
                        <tr>
                            <th>Date & Time</th>
                            <th>Medicine</th>
                            <th>Batch</th>
                            <th>Type</th>
                            <th class="text-center">Qty</th>
                            <th>Balance After</th>
                            <th>User</th>
                            <th>Reference</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($log->quantity < 0 ? 'table-danger' : 'table-success'); ?> opacity-75">
                            <td>
                                <small class="text-muted"><?php echo e($log->created_at->format('d M Y')); ?></small><br>
                                <strong><?php echo e($log->created_at->format('h:i A')); ?></strong>
                            </td>
                            <td>
                                <strong><?php echo e($log->medicine->medicine_name); ?></strong><br>
                                <small class="text-muted"><?php echo e($log->medicine->generic_name); ?></small>
                            </td>
                            <td>
                                <?php if($log->batch): ?>
                                    <span class="badge bg-info"><?php echo e($log->batch->batch_no); ?></span><br>
                                    <small>Exp: <?php echo e($log->batch->expiry_date->format('M Y')); ?></small>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php switch($log->type):
                                    case ('purchase'): ?>  <span class="badge bg-success fs-6">PURCHASE</span> <?php break; ?>
                                    <?php case ('sale'): ?>      <span class="badge bg-danger fs-6">SALE</span> <?php break; ?>
                                    <?php case ('return'): ?>    <span class="badge bg-warning text-dark fs-6">RETURN</span> <?php break; ?>
                                    <?php case ('damage'): ?>    <span class="badge bg-dark fs-6">DAMAGE</span> <?php break; ?>
                                    <?php case ('expiry'): ?>    <span class="badge bg-secondary fs-6">EXPIRED</span> <?php break; ?>
                                    <?php default: ?>           <span class="badge bg-primary"><?php echo e(strtoupper($log->type)); ?></span>
                                <?php endswitch; ?>
                            </td>
                            <td class="text-center fw-bold fs-5">
                                <?php if($log->quantity > 0): ?>
                                    <span class="text-success">+<?php echo e($log->quantity); ?></span>
                                <?php else: ?>
                                    <span class="text-danger"><?php echo e($log->quantity); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                    $balance = \App\Models\MedicineBatch::where('medicine_id', $log->medicine_id)
                                        ->sum('current_stock');
                                ?>
                                <strong><?php echo e($balance); ?></strong>
                            </td>
                            <td>
                                <small><?php echo e($log->user->name); ?></small><br>
                                <span class="text-muted"><?php echo e($log->user->role ?? 'Staff'); ?></span>
                            </td>
                            <td>
                                <?php if($log->reference_type && $log->reference_id): ?>
                                    <a href="#" class="text-decoration-none">
                                        <?php echo e(class_basename($log->reference_type)); ?> #<?php echo e($log->reference_id); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-5 text-muted">
                                <i class="fas fa-box-open fa-3x mb-3 opacity-20"></i>
                                <h4>No stock movement found</h4>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- PAGINATION -->
            <div class="card-footer bg-light">
                <?php echo e($logs->appends(request()->query())->links()); ?>

            </div>
        </div>
    </div>
</div>

<!-- Select2 + Icons -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2({
            placeholder: "Search medicine...",
            width: '100%'
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ricky\Desktop\hms\resources\views/admin/medicine-logs.blade.php ENDPATH**/ ?>