
<?php $__env->startSection('title', 'Pharmacy • CareWell HMS'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100 bg-gradient-to-b from-green-50 to-white">

    <!-- HEADER -->
    <div class="bg-gradient-to-r from-green-600 to-emerald-600 text-white py-6 shadow-xl">
        <div class="container">
            <div class="row align-items-center">
                <div class="col">
                    <h1 class="display-5 fw-bold mb-1">Pharmacy Module</h1>
                    <p class="lead mb-0 opacity-90">
                        Welcome, <strong><?php echo e(Auth::user()->name); ?></strong> • <?php echo e(now()->format('d M Y')); ?>

                    </p>
                </div>
                <div class="col-auto">
                    <div class="text-end">
                        <h3 class="mb-0">Pending: <span class="badge bg-white text-danger fs-4 px-4"><?php echo e($pending->count()); ?></span></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid py-5">
        <div class="row g-5">

            <!-- PENDING PRESCRIPTIONS -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-2xl rounded-4 overflow-hidden">
                    <div class="card-header bg-danger text-white py-4">
                        <h4 class="mb-0 fw-bold">Pending Medicines to Issue</h4>
                    </div>
                    <div class="card-body p-0" style="max-height: 78vh; overflow-y: auto;">
                        <?php $__empty_1 = true; $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $medicine = $order->medicine;
                                $totalStock = $medicine->currentStock(); // Sum of all available batches
                                $canIssue = $totalStock >= 1;
                            ?>

                            <div class="p-5 border-bottom hover:bg-gray-50 transition-all">
                                <div class="row align-items-center">
                                    <div class="col-md-7">
                                        <h5 class="fw-bold text-danger text-xl"><?php echo e($medicine->medicine_name); ?></h5>
                                        <p class="mb-2">
                                            <strong>Patient:</strong> <?php echo e($order->visit->patient->name); ?>

                                            <span class="text-muted">(<?php echo e($order->visit->patient->patient_id); ?>)</span>
                                        </p>
                                        <small class="text-muted">
                                            Dosage: <?php echo e($order->dosage); ?> × <?php echo e($order->duration_days); ?> days
                                        </small>
                                    </div>

                                    <div class="col-md-5">
                                        <?php if($canIssue): ?>
                                            <form action="<?php echo e(route('pharmacy.issue', $order)); ?>" method="POST" class="row g-3 align-items-center">
                                                <?php echo csrf_field(); ?>
                                                <div class="col-5">
                                                    <div class="bg-success bg-opacity-10 text-success fw-bold text-center py-3 rounded-3 border border-success">
                                                        Stock: <?php echo e($totalStock); ?>

                                                    </div>
                                                </div>
                                                <div class="col-3">
                                                    <input type="number" name="quantity_issued" class="form-control form-control-lg text-center fw-bold" 
                                                           value="1" min="1" max="<?php echo e($totalStock); ?>" required>
                                                </div>
                                                <div class="col-4">
                                                    <button type="submit" class="btn btn-success btn-lg w-100 rounded-pill shadow-lg fw-bold">
                                                        Issue
                                                    </button>
                                                </div>
                                            </form>
                                        <?php else: ?>
                                            <div class="alert alert-danger py-3 mb-0 text-center fw-bold">
                                                OUT OF STOCK
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center py-16">
                                <i class="bi bi-check-circle text-success display-1 opacity-20"></i>
                                <h3 class="mt-4 text-success">All prescriptions issued!</h3>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- TODAY ISSUED -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-2xl rounded-4 h-100">
                    <div class="card-header bg-success text-white py-4">
                        <h5 class="mb-0 fw-bold">Issued Today (<?php echo e($issuedToday->count()); ?>)</h5>
                    </div>
                    <div class="card-body p-0" style="max-height: 78vh; overflow-y: auto;">
                        <?php $__empty_1 = true; $__currentLoopData = $issuedToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="p-4 border-bottom hover:bg-gray-50">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <strong class="text-success"><?php echo e($order->medicine->medicine_name); ?></strong><br>
                                        <small class="text-muted">
                                            <?php echo e($order->visit->patient->name); ?> • <?php echo e($order->issued_at->format('h:i A')); ?>

                                        </small>
                                    </div>
                                    <i class="bi bi-check-circle-fill text-success fs-3"></i>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center py-10 text-muted">
                                No medicines issued today
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.hover\:bg-gray-50:hover { background-color: #f9fafb !important; }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ricky\Desktop\hms\resources\views/pharmacy/index.blade.php ENDPATH**/ ?>