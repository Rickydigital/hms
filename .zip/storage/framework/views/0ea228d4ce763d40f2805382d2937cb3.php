
<?php $__env->startSection('title', 'Manage Roles & Permissions'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <h4 class="mb-4 text-primary fw-bold"><i class="bi bi-shield-lock me-2"></i> Roles & Permissions</h4>

    <div class="row g-4">
        <!-- Create Role -->
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-header bg-primary text-white rounded-top-4">
                    <h6 class="mb-0 fw-bold">Create New Role</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.roles')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Role Name</label>
                            <input type="text" name="name" class="form-control rounded-3" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Assign Permissions</label>
                            <div class="row row-cols-2 g-2">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="permissions[]" value="<?php echo e($name); ?>" id="create-<?php echo e($id); ?>">
                                            <label class="form-check-label small" for="create-<?php echo e($id); ?>">
                                                <?php echo e(ucwords(str_replace(['_', '-'], ' ', $name))); ?>

                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary rounded-pill px-4">
                            <i class="bi bi-plus-circle"></i> Create Role
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Roles List -->
        <div class="col-lg-7">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Role</th>
                                    <th>Permissions</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><strong class="text-primary"><?php echo e($role->name); ?></strong></td>
                                    <td>
                                        <div class="d-flex flex-wrap gap-1">
                                            <?php $__currentLoopData = $role->permissions->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="badge bg-info text-dark small"><?php echo e(str_replace('_', ' ', $perm->name)); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($role->permissions->count() > 5): ?>
                                                <span class="badge bg-secondary small">+<?php echo e($role->permissions->count() - 5); ?> more</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-outline-primary rounded-pill" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editRoleModal<?php echo e($role->id); ?>">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                    </td>
                                </tr>

                                <!-- Edit Modal -->
                                <div class="modal fade" id="editRoleModal<?php echo e($role->id); ?>" tabindex="-1">
                                    <div class="modal-dialog modal-lg">
                                        <form action="<?php echo e(url('admin/roles/' . $role->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                            <div class="modal-content border-0 rounded-4 overflow-hidden">
                                                <div class="modal-header bg-gradient-primary text-white">
                                                    <h5 class="modal-title fw-bold">
                                                        <i class="bi bi-shield-lock"></i> Edit Role: <?php echo e($role->name); ?>

                                                    </h5>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-4">
                                                        <label class="form-label fw-bold">Role Name</label>
                                                        <input type="text" name="name" value="<?php echo e($role->name); ?>" class="form-control rounded-3" required>
                                                    </div>
                                                    <div>
                                                        <label class="form-label fw-bold">Permissions</label>
                                                        <div class="row row-cols-2 g-3">
                                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div>
                                                                    <div class="form-check">
                                                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="<?php echo e($name); ?>"
                                                                            id="edit-perm-<?php echo e($role->id); ?>-<?php echo e($id); ?>"
                                                                            <?php echo e($role->hasPermissionTo($name) ? 'checked' : ''); ?>>
                                                                        <label class="form-check-label" for="edit-perm-<?php echo e($role->id); ?>-<?php echo e($id); ?>">
                                                                            <?php echo e(ucwords(str_replace(['_', '-'], ' ', $name))); ?>

                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer bg-light">
                                                    <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-success rounded-pill px-4">
                                                        <i class="bi bi-check2-all"></i> Update Role
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center text-muted py-5">
                                        <i class="bi bi-shield-slash display-4"></i><br>
                                        No roles created yet
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ricky\Desktop\hms\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>