{{-- resources/views/billing/index.blade.php --}}
@extends('components.main-layout')
@section('title', 'Billing Center • Mana Dispensary')

@section('content')
<div class="min-vh-100 bg-gradient-to-b from-blue-50 to-white">

    <!-- HEADER -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-6 shadow-2xl">
        <div class="container">
            <div class="row align-items-center">
                <div class="col">
                    <h1 class="display-5 fw-bold mb-1">Hospital Billing Center</h1>
                    <p class="lead mb-0 opacity-90">Receipts • Payments • Service Tracking</p>
                </div>
                <div class="col-auto">
                    <h3>Pending Bills: <span class="badge bg-warning text-dark fs-4 px-4">{{ $pendingCount }}</span></h3>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid py-5">

        <!-- SEARCH -->
        <div class="card border-0 shadow-lg rounded-4 mb-5">
            <div class="card-body p-5">
                <form action="{{ route('billing.search') }}" method="GET">
                    <div class="row g-4 align-items-center">
                        <div class="col-md-8">
                            <input type="text" name="q" class="form-control form-control-lg rounded-pill shadow-sm"
                                   placeholder="Search by Patient ID or Name..." value="{{ request('q') }}" autofocus>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary btn-lg rounded-pill px-5 shadow-lg w-100 h-100">
                                Search Patient
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- TABS -->
        <ul class="nav nav-tabs mb-5" id="billingTabs">
            <li class="nav-item">
                <a class="nav-link active fs-5 fw-bold" data-bs-toggle="tab" href="#pending">Pending Bills ({{ $pendingCount }})</a>
            </li>
            <li class="nav-item">
                <a class="nav-link fs-5 fw-bold" data-bs-toggle="tab" href="#inprogress">In Progress ({{ $inProgressVisits->count() }})</a>
            </li>
            <li class="nav-item">
                <a class="nav-link fs-5 fw-bold" data-bs-toggle="tab" href="#payments">Payments ({{ $receipts->count() }})</a>
            </li>
        </ul>

        <div class="tab-content">

            <!-- TAB 1: PENDING BILLS -->
            <div class="tab-pane fade show active" id="pending">
                <div class="card border-0 shadow-lg rounded-4">
                    <div class="card-header bg-warning text-dark py-4">
                        <h4 class="mb-0">Ready for Receipt Generation</h4>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-hover mb-0 align-middle">
                            <thead class="bg-light">
                                <tr>
                                    <th>Date</th>
                                    <th>Patient ID</th>
                                    <th>Name</th>
                                    <th>Doctor</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($pendingVisits as $v)
                                <tr>
                                    <td>{{ $v->visit_date->format('d M Y') }}</td>
                                    <td><strong>{{ $v->patient->patient_id }}</strong></td>
                                    <td>{{ $v->patient->name }}</td>
                                    <td>{{ $v->doctor?->name ?? '—' }}</td>
                                    <td class="text-center">
                                        <a href="{{ route('billing.pending.show', $v) }}" class="btn btn-success btn-sm rounded-pill px-4">
                                            Generate Bill
                                        </a>
                                    </td>
                                </tr>
                                @empty
                                <tr><td colspan="5" class="text-center py-5 text-muted fs-4">No pending bills</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                        <div class="card-footer">{{ $pendingVisits->links() }}</div>
                    </div>
                </div>
            </div>

            <!-- TAB 2: IN PROGRESS -->
            <div class="tab-pane fade" id="inprogress">
                <div class="card border-0 shadow-lg rounded-4">
                    <div class="card-header bg-orange text-white py-4">
                        <h4 class="mb-0">Patients with Incomplete Services</h4>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-hover mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>Date</th>
                                    <th>Patient</th>
                                    <th>Stuck At</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($inProgressVisits as $v)
                                <tr>
                                    <td>{{ $v->visit_date->format('d M Y H:i') }}</td>
                                    <td><strong>{{ $v->patient->name }}</strong> ({{ $v->patient->patient_id }})</td>
                                    <td>
                                        @if($v->medicineIssues()->whereNull('pharmacy_issues.issued_at')->exists())
                                            <span class="badge bg-danger">Pharmacy Pending</span>
                                        @elseif($v->labOrders()->where('is_completed', false)->exists())
                                            <span class="badge bg-warning">Lab Results Pending</span>
                                        @elseif($v->injectionOrders()->where('is_given', false)->exists())
                                            <span class="badge bg-info">Injection Pending</span>
                                        @elseif($v->bedAdmission && !$v->bedAdmission->is_discharged)
                                            <span class="badge bg-primary">In Ward</span>
                                        @else
                                            <span class="badge bg-secondary">Unknown</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if($v->all_services_completed)
                                            <span class="badge bg-success">Completed</span>
                                        @else
                                            <span class="badge bg-danger">In Progress</span>
                                        @endif
                                    </td>
                                </tr>
                                @empty
                                <tr><td colspan="4" class="text-center py-5 text-muted fs-4">All services completed</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- TAB 3: PAYMENTS -->
            <div class="tab-pane fade" id="payments">
                <div class="card border-0 shadow-lg rounded-4">
                    <div class="card-header bg-success text-white py-4">
                        <h4 class="mb-0">Receipt & Payment History</h4>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-hover mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>Receipt Date</th>
                                    <th>Patient</th>
                                    <th>Visit ID</th>
                                    <th>Total</th>
                                    <th>Paid</th>
                                    <th>Balance</th>
                                    <th>Status</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($receipts as $r)
                                @php
                                    $paid = $r->visit->payments()->sum('amount');
                                    $balance = $r->grand_total - $paid;
                                @endphp
                                <tr>
                                    <td>{{ $r->generated_at->format('d M Y H:i') }}</td>
                                    <td>{{ $r->visit->patient->name }}</td>
                                    <td>#{{ $r->visit->id }}</td>
                                    <td>Tsh{{ number_format($r->grand_total, 0) }}</td>
                                    <td>Tsh{{ number_format($paid, 0) }}</td>
                                    <td>
                                        @if($balance > 0)
                                            <strong class="text-danger">Tsh{{ number_format($balance, 0) }}</strong>
                                        @else
                                            <span class="text-success fw-bold">PAID</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if($balance <= 0)
                                            <span class="badge bg-success fs-6">FULLY PAID</span>
                                        @elseif($paid > 0)
                                            <span class="badge bg-warning">PARTIAL</span>
                                        @else
                                            <span class="badge bg-danger">UNPAID</span>
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        <!-- View Payment Details Icon -->
                                        <button type="button" class="btn btn-outline-info btn-sm rounded-circle me-2" title="View Payment Details"
                                                data-bs-toggle="modal" data-bs-target="#viewPaymentModal"
                                                onclick="loadPaymentDetails({{ $r->visit->id }})">
                                            <i class="bi bi-eye"></i>
                                        </button>

                                        <!-- Record Payment Button (only if balance > 0) -->
                                        @if($balance > 0)
                                            <button type="button" class="btn btn-primary btn-sm rounded-pill"
                                                    data-bs-toggle="modal" data-bs-target="#paymentModal"
                                                    onclick="openRecordPayment({{ $r->visit->id }}, '{{ addslashes($r->visit->patient->name) }}', {{ $r->grand_total }}, {{ $paid }}, {{ $balance }})">
                                                Pay
                                            </button>
                                        @endif
                                    </td>
                                </tr>
                                @empty
                                <tr><td colspan="8" class="text-center py-5 text-muted fs-4">No receipts generated yet</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- RECORD PAYMENT MODAL -->
<div class="modal fade" id="paymentModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form id="paymentForm" method="POST">
            @csrf
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title fw-bold">Record Payment</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <h5>Patient: <span id="recordPatient" class="text-primary fw-bold"></span></h5>
                    <div class="alert alert-info">
                        <strong>Amount Due:</strong> <span id="recordDue" class="fs-5"></span>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label>Total Bill</label>
                            <input type="text" id="recordTotal" class="form-control bg-light" readonly>
                        </div>
                        <div class="col-md-6">
                            <label>Already Paid</label>
                            <input type="text" id="recordPaid" class="form-control bg-light" readonly>
                        </div>
                        <div class="col-md-6">
                            <label>Amount to Pay *</label>
                            <input type="number" name="amount" id="recordAmount" class="form-control form-control-lg" required step="0.01">
                        </div>
                        <div class="col-md-6">
                            <label>Payment Method *</label>
                            <select name="payment_method" class="form-select form-select-lg" required>
                                <option value="cash">Cash</option>
                                <option value="mpesa">M-Pesa</option>
                                <option value="card">Card</option>
                                <option value="bank_transfer">Bank Transfer</option>
                                <option value="insurance">Insurance</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label>Transaction ID (Optional)</label>
                            <input type="text" name="transaction_id" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success btn-lg px-5">Record Payment</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- VIEW PAYMENT DETAILS MODAL -->
<div class="modal fade" id="viewPaymentModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title fw-bold">Payment Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="paymentDetailsBody">
                <!-- Filled by JS -->
            </div>
        </div>
    </div>
</div>

<script>
// Record Payment Modal
function openRecordPayment(visitId, patientName, total, paid, balance) {
    const form = document.getElementById('paymentForm');
    const amountInput = document.getElementById('recordAmount');

    form.action = `/billing/pay/${visitId}`;
    document.getElementById('recordPatient').textContent = patientName;
    document.getElementById('recordTotal').value = 'Tsh ' + total.toLocaleString();
    document.getElementById('recordPaid').value = 'Tsh ' + paid.toLocaleString();
    document.getElementById('recordDue').textContent = 'Tsh ' + balance.toLocaleString();

    amountInput.value = balance;
    amountInput.max = balance;
    amountInput.min = 1;
}

// View Payment Details Modal
function loadPaymentDetails(visitId) {
    fetch(`/billing/payment-details/${visitId}`)
        .then(r => r.json())
        .then(data => {
            let html = `
                <h5>Patient: <strong>${data.patient}</strong> | Visit #${visitId}</h5>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Total Bill:</strong> Tsh${data.total.toLocaleString()}</p>
                        <p><strong>Total Paid:</strong> Tsh${data.paid.toLocaleString()}</p>
                        <p><strong>Balance:</strong> <span class="${data.balance > 0 ? 'text-danger' : 'text-success'} fw-bold">
                            Tsh${data.balance.toLocaleString()}</span></p>
                    </div>
                </div>
                <h6 class="mt-4 fw-bold text-success">Payment History</h6>
            `;

            if (data.payments.length > 0) {
                html += `<div class="table-responsive"><table class="table table-sm table-bordered">
                    <thead class="table-light">
                        <tr>
                            <th>Date & Time</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Received By</th>
                            <th>Items Paid For</th>
                        </tr>
                    </thead>
                    <tbody>`;

                data.payments.forEach(p => {
                    let items = p.details.map(d => 
                        `${d.item_name} × ${d.quantity} @ Tsh${d.unit_price} = Tsh${d.line_total || d.total_price}`
                    ).join('<br>');
                    html += `<tr>
                        <td>${p.date}</td>
                        <td><strong>Tsh${p.amount}</strong></td>
                        <td><span class="badge bg-info">${p.method}</span></td>
                        <td>${p.received_by}</td>
                        <td class="small">${items || '—'}</td>
                    </tr>`;
                });

                html += `</tbody></table></div>`;
            } else {
                html += `<p class="text-muted">No payments recorded yet.</p>`;
            }

            document.getElementById('paymentDetailsBody').innerHTML = html;
        })
        .catch(() => {
            document.getElementById('paymentDetailsBody').innerHTML = '<p class="text-danger">Failed to load payment details.</p>';
        });
}
</script>
@endsection